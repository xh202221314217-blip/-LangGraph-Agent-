const form = document.querySelector("#query-form");
const queryInput = document.querySelector("#query");
const sendButton = document.querySelector("#send");
const messages = document.querySelector("#messages");

function appendMessage(role, text, extraClass = "") {
  const article = document.createElement("article");
  article.className = `message ${role} ${extraClass}`.trim();

  const meta = document.createElement("div");
  meta.className = "message-meta";
  meta.textContent = role === "user" ? "你" : "回答";

  const body = document.createElement("p");
  body.textContent = text;

  article.append(meta, body);
  messages.appendChild(article);
  messages.scrollTop = messages.scrollHeight;
  return body;
}

function parseSSEChunk(chunk) {
  return chunk
    .split("\n\n")
    .flatMap((event) => event.split("\n"))
    .filter((line) => line.startsWith("data:"))
    .map((line) => line.slice(5).trim())
    .filter(Boolean);
}

async function submitQuery(query) {
  appendMessage("user", query);
  const answer = appendMessage("assistant", "", "pending");
  answer.textContent = "正在处理请求...";

  const body = new FormData(form);
  body.set("query", query);

  sendButton.disabled = true;
  sendButton.textContent = "检索中";

  try {
    const response = await fetch("/api/langgraph/query", {
      method: "POST",
      body,
    });

    if (!response.ok || !response.body) {
      throw new Error(`请求失败：HTTP ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let pending = "";
    let receivedAnswer = false;

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      pending += decoder.decode(value, { stream: true });
      const boundary = pending.lastIndexOf("\n\n");
      if (boundary === -1) continue;

      const complete = pending.slice(0, boundary + 2);
      pending = pending.slice(boundary + 2);

      for (const payload of parseSSEChunk(complete)) {
        try {
          const parsed = JSON.parse(payload);
          if (!receivedAnswer) {
            answer.textContent = "";
            receivedAnswer = true;
          }
          answer.textContent += typeof parsed === "string" ? parsed : JSON.stringify(parsed);
        } catch {
          if (!receivedAnswer) {
            answer.textContent = "";
            receivedAnswer = true;
          }
          answer.textContent += payload;
        }
      }
      messages.scrollTop = messages.scrollHeight;
    }

    if (!answer.textContent.trim()) {
      answer.textContent = "没有收到可展示的回答。请检查后端日志和知识库配置。";
    }
  } catch (error) {
    answer.textContent = error instanceof Error ? error.message : "请求失败。";
  } finally {
    answer.parentElement.classList.remove("pending");
    sendButton.disabled = false;
    sendButton.textContent = "开始检索";
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const query = queryInput.value.trim();
  if (!query) return;
  queryInput.value = "";
  submitQuery(query);
});

queryInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll(".sample").forEach((button) => {
  button.addEventListener("click", () => {
    queryInput.value = button.textContent.trim();
    queryInput.focus();
  });
});
